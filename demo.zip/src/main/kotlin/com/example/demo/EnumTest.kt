package com.example.demo

enum class EnumTest {
    V1,
    V2
}